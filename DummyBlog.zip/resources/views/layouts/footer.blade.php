<footer class="blog-footer">
      <p>Copyright@2018 Built by Hardik Panchal</p>
      <p>
        <a href="#" style="color:#d4534f">Back to top</a>
      </p>
</footer>